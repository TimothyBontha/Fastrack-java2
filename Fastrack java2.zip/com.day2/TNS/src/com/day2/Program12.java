package com.day2;

public class Program12 {
	
	public static void main(String args[ ])  {
	       Program10 obj1 = new Program11();
	        
	       // As per overriding rules this should call to class Derive's static
	       // overridden method. Since static method can not be overridden, it
	       // calls Base's display()
	       obj1.display(); 
	        
	       // Here overriding works and Derive's print() is called
	       obj1.print();    
	    }

}